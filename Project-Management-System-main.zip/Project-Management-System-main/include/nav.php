<nav>
    <div class="title">PROJECT MANAGEMENT SYSTEM</div>
</nav>